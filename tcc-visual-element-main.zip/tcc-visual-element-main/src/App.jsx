import React from 'react';
import './App.css';
import Router from './routes.jsx';

function App() {
  return (
      <div>
        <Router />
      </div>
  );
}

export default App;
